# Import necessary Ghidra modules
from ghidra.program.model.listing import CodeUnit
from ghidra.program.model.symbol import SymbolUtilities
from ghidra.program.model.scalar import Scalar
from ghidra.app.script import GhidraScript
import base64

class StringDecryptionScript(GhidraScript):
    def run(self):
        currentProgram = self.getCurrentProgram()
        if currentProgram is None:
            self.println("No program is currently loaded.")
            return

        self.println("Program loaded successfully.")
        
        memory = currentProgram.getMemory()
        start = currentProgram.getMinAddress()
        end = currentProgram.getMaxAddress()
        
        self.println("Reading memory from {} to {}".format(start, end))

        try:
            # Update the file path
            file_path = "C:\\Users\\User\\Desktop\\413 Final\\encrypted2.bin"
            with open(file_path, "rb") as file:
                encrypted_data = file.read()
                self.println("Encrypted data read successfully from {}".format(file_path))
                self.println("Memory data length: {}".format(len(encrypted_data)))
                self.println("First 50 bytes of encrypted data: {}".format(encrypted_data[:50]))
        except Exception as e:
            self.println("Error reading file: {}".format(e))
            return
        
        # Attempt to decrypt the encrypted data
        self.println("Attempting to decrypt data")
        decrypted_data = self.xorDecrypt(encrypted_data)
        
        if decrypted_data:
            self.println("Decryption successful")
            self.println("Decrypted data: {}".format(decrypted_data))
        else:
            self.println("Decryption failed")

    def xorDecrypt(self, data):
        self.println("XOR decryption started")
        # Define the key explicitly
        key = [ord(c) for c in "BLAbla$!"]
        
        # Print out the key for verification
        self.println("Using key: {}".format(key))
        
        # Verify key length
        self.println("Key length: {}".format(len(key)))

        decrypted = bytearray()
        key_length = len(key)
        for i in range(len(data)):
            decrypted.append(data[i] ^ key[i % key_length])
        
        try:
            decrypted_string = decrypted.decode('utf-8', errors='ignore')
            self.println("Decrypted XOR data: {}".format(decrypted_string))
            return decrypted_string
        except Exception as e:
            self.println("XOR decryption error: {}".format(e))
            return None

# The following line is not necessary and should be removed because Ghidra manages script execution
# script = StringDecryptionScript()
# script.run()
